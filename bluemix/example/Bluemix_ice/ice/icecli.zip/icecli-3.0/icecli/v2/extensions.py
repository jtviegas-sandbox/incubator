__author__ = 'asyousse'
#
#extension points for IDS pipeline support
#
# pre and post command processing handler names defined in 2 env variables

import os
import commands

ICE_CLI_PRE_HANDLER = os.environ.get('ICE_CLI_PRE_HANDLER', '')
ICE_CLI_POST_HANDLER = os.environ.get('ICE_CLI_POST_HANDLER', '')

def handler1(ns):
    commands.debug('Enter handler1 >> ')
    commands.debug(ns)
    commands.debug('Exit handler1 << ')
    return 0

def handler2(ns):
    commands.debug('Enter handler2 >> ')
    commands.debug(ns)
    commands.debug('Exit handler2 << ')
    return 0
